<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
	
	
<body>


</body>
</html>

<?php

	require_once("fluxRss.php");
	require_once("MySQL/mysql.class.php");
	require_once("pageWeb_Nettoyage/pageWeb.php");
	require_once("Readability/Readability.php");
	
	ini_set('max_execution_time', 500); 
	
	libxml_use_internal_errors(true);

	$bd = new MySQL();
	
	$maladies = $bd->requete_select_simple("maladies");
	
	$symptoms = $bd->requete_select_simple("symptoms");
	
	$i = 0; //
			//
	$j = 0;	// Compteur d'articles, pour les stats et l'évaluation.
			//
	$k = 0; //
	
	$keywords = array_merge($maladies,$symptoms);
	
	
	foreach($keywords as $valeur)
	{
		$f = new fluxRSS();
	
		if($valeur["host"] != NULL)
		{
			$mot_clés = $valeur["keyword"]."+".$valeur["host"];
		}
		else
		{
			$mot_clés = $valeur["keyword"];
		}
		
		$urlGoogle = $f->creer_rss_gnews($mot_clés);
		
		$urlGoogle = mysql_real_escape_string($urlGoogle);
		
		$url_md5_10 = substr(md5($urlGoogle),0,10);
				
		if(!$bd->mysql_exists("fluxRss","id",$url_md5_10)) 
		{	
					$tab_bd = array("id" => $url_md5_10,
									"url" => $urlGoogle
									);
					
					$bd->requete_insert("fluxRss",$tab_bd);
					$i++;
		}
		
	}
	
	echo $i." nouveau(x) flux ajouté(s)\n";
	
	
	//Début Script MySql
		
	$res = $bd->requete_select_simple("fluxRss");
	
	if(!$res)
	{
		
		die("Erreur :".mysql_error());
	
	}
	

	
	foreach($res as $flux)
	{
		$array[] = new fluxRss($flux["url"]);
	}
	
	foreach($array as $valeur)
	{
		$valeur->chargementRSS();
		
		echo "</br>| RSS : ".$valeur->getURL()." |</br>";
		
		if ($valeur->arrayArticles[0] != NULL)
		{
			foreach($valeur->arrayArticles as $valeur2)
			{
				$j++;
				
				$desc=$valeur2->getDescription();
				$lien=$valeur2->getLien();
				$titre=$valeur2->getTitre();
				
				$titre_md5_10 = substr(md5($titre),0,10);
				
				foreach($keywords as $keyword)
				{	
						if( preg_match("#(disease|case|outbreak|infection|infestation|pathogen|virus|bacteria|illness|syndrome|parasite|serotype|reported|detected)#",$titre)  && preg_match("#(disease|case|outbreak|infection|infestation|pathogen|virus|bacteria|illness|syndrome|parasite|serotype)#",$desc) )
						{
							/* Verification des maladies */
							
							//if( preg_match("#((" .$keyword["keyword"]. ")*.(" .$keyword["host"]. ")) | ((" .$keyword["host"]. ")*.(" .$keyword["keyword"]. "))#",$titre) && preg_match("#((" .$keyword["keyword"]. ")*.(" .$keyword["host"]. ")) | ((" .$keyword["host"]. ")*.(" .$keyword["keyword"]. "))#",$desc)  )
							if( preg_match("#" .$keyword["keyword"]. "#",$titre) && preg_match("#" .$keyword["keyword"]. "#",$desc) )
							{
								$k++;
								if(!$bd->mysql_exists("articleWeb","id",$titre_md5_10))
								{
									
									$page = new pageWeb($lien);
									$str = $page->nettoyerPage();
									
									echo "\n ***Il n'existe pas***\n";
									
									//preg_replace("/^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/","",$str);
									
									$str = $str."\n#datearemp\n#coordtemp"; //Pour text mining , à remplacer par la date de l'article et les coordonnées géolocalisations
																
									$tab_valeurs = array("id" => $titre_md5_10,
														 "titre" => mysql_real_escape_string($titre), 
														 "url" => mysql_real_escape_string($lien),
														 "texte" => mysql_real_escape_string($str),
														 "categorie" => mysql_real_escape_string($keyword["categorie"])
														 );
								
									$bd->requete_insert("articleWeb",$tab_valeurs);
									
									echo "\nArticle Engeristré :";
									
									echo "<p>".$titre . " (" . $lien . ")</p><p>" . $str. "</p></br>" ; 
								}
								
								else
								{
									echo "<p>***Cet article est déjà présent dans la BDD*** Article Suivant ***</p>";
								}
								
								
								
								
								break; //pour éviter que le script ne boucle sur le même article pour tout les mots clés
							}
						}
					}
			}
		}	
			echo "==================================================";
	}
	
	echo "\n".$j." articles parcouru // ".$k." articles jugés bon";
		
		
	?>
