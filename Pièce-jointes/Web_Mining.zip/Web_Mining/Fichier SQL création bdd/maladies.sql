-- phpMyAdmin SQL Dump
-- version 4.4.12
-- http://www.phpmyadmin.net
--
-- Client :  localhost
-- Généré le :  Ven 28 Août 2015 à 13:18
-- Version du serveur :  5.6.26
-- Version de PHP :  5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `belotb`
--

-- --------------------------------------------------------

--
-- Structure de la table `maladies`
--

CREATE TABLE IF NOT EXISTS `maladies` (
  `id` int(11) NOT NULL,
  `keyword` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `host` varchar(255) NOT NULL,
  `categorie` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=282 DEFAULT CHARSET=utf8;

--
-- Contenu de la table `maladies`
--

INSERT INTO `maladies` (`id`, `keyword`, `host`, `categorie`) VALUES
(142, 'Horse Sickness African', '', 'African Horse Sickness'),
(143, 'Sickness African Horse', '', 'African Horse Sickness'),
(144, 'Equine Plague', '', 'African Horse Sickness'),
(145, 'Plague Equine', '', 'African Horse Sickness'),
(146, 'African Horsesickness', '', 'African Horse Sickness'),
(147, 'Horsesickness African', '', 'African Horse Sickness'),
(148, 'African Horse Sickness', '', 'African Horse Sickness'),
(149, 'African swine fever ', '', 'African swine fever'),
(150, 'Wart-Hog Disease', '', 'African swine fever'),
(151, 'Wart Hog Disease', '', 'African swine fever'),
(152, 'Swine Fever African', '', 'African swine fever'),
(153, 'Asfivirus infection', '', 'African swine fever'),
(154, 'Bluetongue', '', 'Bluetongue'),
(155, 'Bovine brucellosis', '', 'Bovine brucellosis'),
(156, 'Brucellosis bovine', '', 'Bovine brucellosis'),
(157, 'B.abortus', '', 'Bovine brucellosis'),
(158, 'Brucella abortus', '', 'Bovine brucellosis'),
(159, 'Bang''s Disease', '', 'Bovine brucellosis'),
(160, 'Bangs Disease', '', 'Bovine brucellosis'),
(161, 'Disease Bang''s', '', 'Bovine brucellosis'),
(162, 'Bang Disease', '', 'Bovine brucellosis'),
(163, 'Disease Bang', '', 'Bovine brucellosis'),
(164, 'Classical swine fever ', '', 'Classical swine fever '),
(165, 'Swine Fever Classical', '', 'Classical swine fever '),
(166, 'Hog Cholera', '', 'Classical swine fever '),
(167, 'Cholera Hog', '', 'Classical swine fever '),
(168, 'Contagious bovine pleuropneumonia', '', 'Contagious bovine pleuropneumonia'),
(169, 'Eastern equine encephalitis', '', 'Eastern equine encephalitis'),
(170, 'Eastern equine encephalomyelitis', '', 'Eastern equine encephalitis'),
(171, 'Equine Encephalomyelitis Eastern', '', 'Eastern equine encephalitis'),
(172, 'Eastern Equine Encephalomyelitis', '', 'Eastern equine encephalitis'),
(173, 'Eastern Equine Encephalitis', '', 'Eastern equine encephalitis'),
(174, 'Encephalitis Eastern Equine', '', 'Eastern equine encephalitis'),
(175, 'Equine Encephalitis Eastern', '', 'Eastern equine encephalitis'),
(176, 'Epizootic haemorrhagic disease', '', 'Epizootic haemorrhagic disease'),
(177, 'Epizootic hemorrhagic disease', '', 'Epizootic haemorrhagic disease'),
(178, 'Foot and mouth disease ', '', 'Foot and mouth disease '),
(179, 'Foot-and-mouth disease', '', 'Foot and mouth disease '),
(180, 'Highly pathogenic avian influenza ', '', 'Highly pathogenic avian influenza '),
(181, 'Influenza in Bird', '', 'Highly pathogenic avian influenza '),
(182, 'Avian Influenza', '', 'Highly pathogenic avian influenza '),
(183, 'Influenza Avian', '', 'Highly pathogenic avian influenza '),
(184, 'Avian Flu', '', 'Highly pathogenic avian influenza '),
(185, 'Flu Avian', '', 'Highly pathogenic avian influenza '),
(186, 'Fowl Plague', '', 'Highly pathogenic avian influenza '),
(187, 'Plague Fowl', '', 'Highly pathogenic avian influenza '),
(188, 'H5N1 HPAI', '', 'Highly pathogenic avian influenza '),
(189, 'H5N2 HPAI', '', 'Highly pathogenic avian influenza '),
(190, 'H5N3 HPAI', '', 'Highly pathogenic avian influenza '),
(191, 'H5N7 HPAI', '', 'Highly pathogenic avian influenza '),
(192, 'H5N9 HPAI', '', 'Highly pathogenic avian influenza '),
(193, 'H5N8 HPAI', '', 'Highly pathogenic avian influenza '),
(194, 'H5 HPAI', '', 'Highly pathogenic avian influenza '),
(195, 'H5N6 HPAI', '', 'Highly pathogenic avian influenza '),
(196, 'H7 HPAI', '', 'Highly pathogenic avian influenza '),
(197, 'H7N1 HPAI', '', 'Highly pathogenic avian influenza '),
(198, 'H7N3 HPAI', '', 'Highly pathogenic avian influenza '),
(199, 'H7N7 HPAI', '', 'Highly pathogenic avian influenza '),
(200, 'H7N2 HPAI', '', 'Highly pathogenic avian influenza '),
(201, 'Encephalitis Japanese', '', 'Japanese Encephalitis'),
(202, 'Japanese encephalitis', '', 'Japanese Encephalitis'),
(203, 'Virus Nipah', '', 'Nipah Virus infection'),
(204, 'Nipah encephalitis', '', 'Nipah Virus infection'),
(205, 'Nipah virus encephalitis', '', 'Nipah Virus infection'),
(206, 'Nipah virus encephalitis', '', 'Nipah Virus infection'),
(207, 'Ovine brucellosis', '', 'Ovine and caprine brucellosis'),
(208, 'Caprine brucellosis', '', 'Ovine and caprine brucellosis'),
(209, 'Brucellosis ovine', '', 'Ovine and caprine brucellosis'),
(210, 'Brucellosis caprine', '', 'Ovine and caprine brucellosis'),
(211, 'Brucella melitensis', '', 'Ovine and caprine brucellosis'),
(212, 'B.melitensis', '', 'Ovine and caprine brucellosis'),
(213, 'Peste des Petits Ruminants', '', 'Peste des petits ruminants'),
(214, 'Pseudorinderpest', '', 'Peste des petits ruminants'),
(215, 'Peste-des-Petits-Ruminants', '', 'Peste des petits ruminants'),
(216, 'Porcine epizootic diarrhea', '', 'Porcine epizootic diarrhoea'),
(217, 'Porcine epizootic diarrhoea', '', 'Porcine epizootic diarrhoea'),
(218, 'Lyssa', '', 'Rabies'),
(219, 'Hydrophobia', '', 'Rabies'),
(220, 'Rabies', '', 'Rabies'),
(221, 'Rift Valley Fever', '', 'Rift Valley Fever'),
(222, 'Rinderpest', '', 'Rinderpest'),
(223, 'Cattle Plague', '', 'Rinderpest'),
(224, 'Plague Cattle', '', 'Rinderpest'),
(225, 'Schmallenberg virus infection', '', 'Schmallenberg virus infection'),
(226, 'Schmallenberg disease', '', 'Schmallenberg virus infection'),
(227, 'Schmallenberg virus', '', 'Schmallenberg virus infection'),
(228, 'Vesicular Disease Swine', '', 'Swine vesicular disease'),
(229, 'Swine vesicular disease', '', 'Swine vesicular disease'),
(230, 'Equine Encephalomyelitis Venezuelan', '', 'Venezuelan equine encephalomyelitis'),
(231, 'Venezuelan Equine Encephalomyelitis', '', 'Venezuelan equine encephalomyelitis'),
(232, 'Venezuelan Equine Encephalitis', '', 'Venezuelan equine encephalomyelitis'),
(233, 'Encephalitis Venezuelan Equine', '', 'Venezuelan equine encephalomyelitis'),
(234, 'Equine Encephalitis Venezuelan', '', 'Venezuelan equine encephalomyelitis'),
(235, 'Vesicular stomatitis', '', 'Vesicular stomatitis'),
(236, 'Stomatitis Vesicular', '', 'Vesicular stomatitis'),
(237, 'West Nile Fever Myelitis', '', 'West Nile fever'),
(238, 'West Nile Fever Meningoencephalitis', '', 'West Nile fever'),
(239, 'Encephalitis West Nile Fever', '', 'West Nile fever'),
(240, 'West Nile Fever Encephalitis', '', 'West Nile fever'),
(241, 'West Nile Fever Meningitis', '', 'West Nile fever'),
(242, 'West Nile fever', '', 'West Nile fever'),
(243, 'Western equine encephalitis', '', 'Western equine encephalitis'),
(244, 'Western Equine Encephalomyelitis', '', 'Western equine encephalitis'),
(245, 'Western Equine Encephalitis', '', 'Western equine encephalitis'),
(246, 'Encephalitis Western Equine', '', 'Western equine encephalitis'),
(247, 'Equine Encephalitis Western', '', 'Western equine encephalitis'),
(248, 'Infestation honey bees Tropilaelaps', '', 'Tropilaelaps infestation'),
(249, 'Tropilaelaps infestation ', '', 'Tropilaelaps infestation'),
(250, 'Tropilaelaps infestation honey bees', '', 'Tropilaelaps infestation'),
(251, 'Tropilaelaps clareae', '', 'Tropilaelaps infestation'),
(252, 'Aethina tumida infestation', '', 'Aethina tumida infestation'),
(253, 'Aethina tumida', '', 'Aethina tumida infestation'),
(254, 'Infestation Aethina tumida', '', 'Aethina tumida infestation'),
(255, 'Infestation small hive beetle', '', 'Aethina tumida infestation'),
(256, 'Small hive beetle infestation', '', 'Aethina tumida infestation'),
(257, 'Small hive beetle', '', 'Aethina tumida infestation'),
(258, 'Nosemosis honey bees', '', 'Nosemosis'),
(259, 'Nosema apis ', '', 'Nosemosis'),
(260, 'Paenibacillus larvae', '', 'American foulbrood'),
(261, 'American foulbrood', '', 'American foulbrood'),
(262, 'Disease Lumpy Skin', '', 'Lumpy skin disease'),
(263, 'Lumpy Skin disease', '', 'Lumpy skin disease'),
(264, 'Skin Disease Lumpy', '', 'Lumpy skin disease'),
(265, 'Enzootic Porcine Encephalomyelitis', '', 'Teschen disease'),
(266, 'Porcine Encephalomyelitis Enzootic', '', 'Teschen disease'),
(267, 'Porcine Poliomyelitis', '', 'Teschen disease'),
(268, 'Poliomyelitis Porcine', '', 'Teschen disease'),
(269, 'Talfan Disease', '', 'Teschen disease'),
(270, 'Disease Talfan', '', 'Teschen disease'),
(271, 'Teschen Disease', '', 'Teschen disease'),
(272, 'Disease Teschen', '', 'Teschen disease'),
(273, 'Sheeppox virus', '', 'Sheep and goat pox'),
(274, 'Sheep Pox Virus', '', 'Sheep and goat pox'),
(275, 'Pox Virus Sheep', '', 'Sheep and goat pox'),
(276, 'Goatpox virus', '', 'Sheep and goat pox'),
(277, 'Goat Pox Virus', '', 'Sheep and goat pox'),
(278, 'Capripoxvirus', '', 'Sheep and goat pox'),
(279, 'Goat pox', '', 'Sheep and goat pox'),
(280, 'Sheep pox', '', 'Sheep and goat pox'),
(281, 'West Nile virus', '', 'West Nile fever');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `maladies`
--
ALTER TABLE `maladies`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `maladies`
--
ALTER TABLE `maladies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=282;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
