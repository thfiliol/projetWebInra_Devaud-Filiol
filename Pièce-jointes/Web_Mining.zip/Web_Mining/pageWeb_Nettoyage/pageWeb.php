<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
	
	
<body>


</body>
</html>

<?php

	//Décrit une page web (ou plus précisement, un article web) grâce à son URL, le code source de la page, et le texte de l'article récupéré

	class pageWeb
	{
		
		private $URL;
		private $source;
		private $articleNettoyé;
		
		//Constructeur 
		//Paramètre : Un URL d'article OU rien
		
		public function __construct($url=null){
			
			$this->URL=$url;
			if($url != null) {  //Si l'url n'est pas nulle, on va chercher le code source de la page automatiquement
				$this->obtenirSource();
			}
			
		}
		
		
		public function obtenirSource(){
			
			$this->source = $this->curl_obtenir_html($this->URL); 
			
		}
		
		public function getSource(){
			
			
			return $this->source;
		}
		
		public function getURL(){
			
			return $this->source;
		
		}
		
		protected function curl_obtenir_html($url)
		{
			//Récupère le code source d'une page web grâce à son URL
			
			//Paramètre : URL de la page
			
			
			// create curl resource
			$ch = curl_init();
			
			
			curl_setopt_array($ch, array(
				CURLOPT_FOLLOWLOCATION => true,
				CURLOPT_HEADER  => false,
				CURLOPT_HTTPGET => true,
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_TIMEOUT => 10000,
			));
			
			curl_setopt($ch, CURLOPT_COOKIEJAR, '/tmp/cookies.txt');
			curl_setopt($ch, CURLOPT_COOKIEFILE, '/tmp/cookies.txt');

			// set url
			curl_setopt($ch, CURLOPT_URL, "$url");

			//return the transfer as a string
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch,CURLOPT_USERAGENT,'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.13) Gecko/20080311 Firefox/2.0.0.13');

			// $output contains the output string
			$output = curl_exec($ch);

			// close curl resource to free up system resources
			curl_close($ch);
			
			
			return $output;
			
		}
		
		protected function SmartQuote_to_Regular(){
			//Remplace certain caractères spéciaux (smartquote par exemple) par leur équivalent en caractère normal
			
			
			$string = $this->articleNettoyé;
			
			$string = str_replace("“",'"',$string);
			$string = str_replace("”",'"',$string);
			$string = str_replace("’","'",$string);
			$string = str_replace("‘","'",$string);
			$string = str_replace("—","-",$string);
			$string = str_replace("–","-",$string);
			$string = str_replace("•","_",$string);
			$string = str_replace(";",";",$string);
			$string = str_replace("…","...",$string);
			
			return $string;
			
		}
		
		
		public function nettoyerPage(){
		
			//Nettoie le code source de la page web pour ne récupérer que le corpus de l'article sans balises
		
		
			$html = $this->source;

			// Note: PHP Readability expects UTF-8 encoded content.
			// If your content is not UTF-8 encoded, convert it 
			// first before passing it to PHP Readability. 
			// Both iconv() and mb_convert_encoding() can do this.

			// If we've got Tidy, let's clean up input.
			// This step is highly recommended - PHP's default HTML parser
			// often doesn't do a great job and results in strange output.
			/*
			if (function_exists('tidy_parse_string')) {
				$tidy = tidy_parse_string($html, array(), 'UTF8');
				$tidy->cleanRepair();
				$html = $tidy->value;
			}*/

			// give it to Readability
			$readability = new Readability($html, $this->URL);
			// print debug output? 
			// useful to compare against Arc90's original JS version - 
			// simply click the bookmarklet with FireBug's console window open
			$readability->debug = false;
			// convert links to footnotes?
			$readability->convertLinksToFootnotes = true;
			// process it
			$result = $readability->init();
		
			// does it look like we found what we wanted?
			if ($result) {
				$str="";
				$str= $str.$readability->getTitle()->textContent."\n\n";
				$content = $readability->getContent()->innerHTML."";
				// if we've got Tidy, let's clean it up for output
				if (function_exists('tidy_parse_string')) {
					$tidy = tidy_parse_string($content, array('indent'=>true, 'show-body-only' => true), 'UTF8');
					$tidy->cleanRepair();
					$content = $tidy->value;
				}
				$this->articleNettoyé= $str.$readability->getContent()->textContent."";
				
				$str = $this->SmartQuote_to_Regular();
			} 
			
			else {
					$str= 'Contenu Introuvable.';
				}
				
			
				
			return $str;
					
		}
								
	}

?>
