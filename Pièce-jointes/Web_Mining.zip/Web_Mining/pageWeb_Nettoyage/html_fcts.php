<?php
	function form_txt ($texte)
		{
			$police='<font face="verdana" size="2" color="#CCCCCC" >';
			$fin_police='</font>';
			
			$txt_formate = $police . $texte . $fin_police;
			return ($txt_formate);
		}
	
	
	function clean_LongBalise ($chaine_html, $balise)
	/*
	Permet de nettoyer les balise n'étant pas encadrée directement
		exemple : <body id="" blablabla> sera nettoyé en <body>
	*/
		{
			$motif = '#<'. $balise . '(.*?)>#';
			$lgBalise=preg_replace($motif,'<' . $balise .'>',$chaine_html,-1);
			return ($lgBalise);
		}
		
		
	function recup_InfoBalise ($chaine_html, $balise)
	/*
	Permet de récupérer l'info d'une balise passée en paramètre sur une chaine HTML
	*/
		{
			$motif='#<' . $balise . '>(.*)<\/' . $balise . '>#is';
			
			$result=preg_match_all($motif,$chaine_html,$tab_result);
			
			for ($i = 0; $i <= count($tab_result[1])-1; $i++)
				{
					//$temp=str_replace('>','',($tab_result[1][$i]));
					//$temp=str_replace('<','',$temp);
					$infoBalise=$tab_result[1][$i];
					echo form_txt($infoBalise) . '<br>';
					//echo htmlspecialchars($infoBalise) . '<br>';
				}
	
		}
		
	function supp_Balise ($chaine_html, $balise)
	/* 
	Permet de supprimer une balise --> utile pour les tableau par exemple
	*/
		{
			//$motif = '#<'. $balise . '#';
			$motif = '#<'. $balise . '>#';			
			$sans_balise=preg_replace($motif,'',$chaine_html,-1);
			
			$motif = '#<\/'. $balise . '>#';
			//$motif = '#\/'. $balise . '>#';			
			$sans_balise=preg_replace($motif,'',$sans_balise,-1);
			
			return ($sans_balise);
		}
		
	function suppScript($chaine_html)
	/*
	Permet de supprimer les script du code
	*/
		{
			$motif = '@<script[^>]*?>.*?</script>@si';
			$lgBalise=preg_replace($motif,'',$chaine_html,-1);
			return ($lgBalise);
		}
		
	function suppStyle($chaine_html)
	/*
	Permet de supprimer les script du code
	*/
		{
			$motif = '@<style[^>]*?>.*?</style>@si';
			$lgBalise=preg_replace($motif,'',$chaine_html,-1);
			return ($lgBalise);
		}

?>
