<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

</head>
	
	
<body>


</body>
</html>

<?php

require_once("articleRss.php");

require_once("MySQL/mysql.class.php");

//Classe pour gérer les flux RSS à aspirer

	class fluxRss
	{
		
		private $URL; //URL du flux
		public $arrayArticles; //tableau d'articles récupérés 
	
		//Constructeur 
		
		//Paramètre : URL du flux à aspirer
		//Construit l'objet fluxRSS avec son URL
		public function __construct($URL=null){
			
			$this->URL=$URL; 
			
		}
		
		//Charge les articles provenant de l'URL de l'objet courant et les stockes dans arrayArticles 
		//
		public function chargementRSS(){
			
			$str=""; //
			
			
			if($flux = simplexml_load_file($this->URL) ) //Accès à l'URL et test si la requête HTTP s'est faite correctement 
			{
			   $donnee = $flux->channel; //Récupération du flux d'articles
			   //Lecture des données
				if ($donnee->item[0] != NULL)
				   {
					   foreach($donnee->item as $valeur)
						   { 
							  $this->arrayArticles[]= new articlesRss($valeur->title,$valeur->link,$valeur->description); //Pour chaque item du flux, on le stocke en tant qu'articleRss dans l'attribut arrayArticles
							  
						   }
					}
			}
			
		}
		
		public function getURL(){
			
			return $this->URL; // getter pour l'URL
		
		
		}
		
		public function creer_rss_gnews($mot_clés){
			//Paramètre : mot(s) clé(s) de recherche
			//Permet de créer un flux RSS provenant de google news à partir de mot clés
			
			//Exemple avec le mot clé "Blue tongue" :
			//https://news.google.com/news/feeds?pz=1&cf=all&ned=en&q=Blue+tongue&output=rss
			
			$mot_clés_google = str_replace(" ", "+" ,$mot_clés); // On remplace les espaces par des "+" pour respecter la syntaxe de Google
			
			$urlRSS = "https://news.google.com/news/feeds?pz=1&cf=all&ned=en&q=".$mot_clés_google."&output=rss"; // On place le(s) mot(s) clé(s) formaté(s)
					
			return $urlRSS; //On retourne la nouvelle URL
			
		}
		
		public function getArrayArticles(){
			
			return $this->arrayArticles; //getter pour le tableau d'article
		}

	}

?>
