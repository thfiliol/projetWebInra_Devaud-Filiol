<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>	
	
<body>


</body>
</html>

<?php

//header('Content-Type: text/plain; charset=utf-8');
class MySQL
{
  var $nomServeur=null;     // Nom d'host : initialiser dans util_mysql()
  var $nomDB=null;          // Nom de la base de donnÔøΩes
  var $nomUser=null;        // Utilisateur courant : initialiser dans util_mysql()
  var $password=null;       // Mot de passe associÔøΩ ÔøΩ $user : initialiser dans util_mysql()
  var $res_result=null;
  
  var $nomConnexion=null;   // Nom de la connexion
  var $nomTable=null;       // Nom de la table sur laquelle on effectue les opÔøΩrations : initialiser dans recupStructure()
  var $nomChamp=null;       // Nom du champ 
  var $nbChamp=null;        // Nombre de champs 
  
  var $SQL=null;            // Contien la requête SQL
  var $SQLResult=null;
  var $contenuResult=null;  // Requête SELECT
  var $structTab=null;      // Contient la structure d'une table

  
  
  //-- Constructeur de la clsse
  function MySQL(){
    include("db_config.php");
	$this->nomServeur = $nomServeur;
	$this->nomDB = $nomDB;
	$this->nomUser = $nomUser;
	$this->password = $password; 
	
	// Ouverture de la connexion
	$this->connect();
  }

  // Connexion ÔøΩ la base de donnÔøΩes.
  function connect(){
    $this->connexion = mysql_connect($this->nomServeur, $this->nomUser, $this->password) or die("Impossible de se connecter : " . mysql_error());
    mysql_select_db($this->nomDB) or die("La sÔøΩlÔøΩction de la base de donnÔøΩes a ÔøΩchouÔøΩ");
  }
  
  // Ferme la connexion ÔøΩ la base de donnÔøΩes.
  function close(){
    mysql_close($this->connexion);
  }

  //-- Efface le rÔøΩsultat de la requÔøΩte de la mÔøΩmoire
  function free(){
    @mysql_free_result();
    return true;
  }

  // R√©cup√®re la structure d'une table
  function getStruct($nomTable){
    $this->nomTable = $nomTable;
    $this->res_result = mysql_list_fields($this->nomDB, $this->nomTable) or die("Echec : ".$this->dbname." , ".$this->$table." <br/>".mysql_error());
    $this->nbChamp = mysql_num_fields($this->res_result);
	for($i=0; $i<$this->nbChamp; $i++){
	  $this->structTab[$i] = mysql_field_name($this->res_result,$i);
	}
  }

  // Ex√©cute une requ√™te SQL et place le r√©sultat dans 
  // l'attribut contenuResult
  function exec_SQL(){
        // Initialisation de contenuResult 
	$this->contenuResult="";
	// Ex√©cution de la requÔøΩte
	$this->SQLResult = mysql_query($this->SQL) or die("La requête a échouée : $this->SQL".mysql_error());

	// s'il s'agit d'une requ√™te SELECT 
	if(@ereg("SELECT", $this->SQL)==true AND @ereg("CREAT", $this->SQL)==false){
	// $nb re√ßoit le nombre de lignes de r√©sltats
            $nb = mysql_num_rows($this->SQLResult); 
            $i=0;
            if($nb != 0){
                // Affectation de contenuResult
                while ($this->contenuResult[$i] = mysql_fetch_assoc($this->SQLResult) and $i<$nb-1){
                    $i++;
                }
                $this->SQL = str_replace("  ", " ", $this->SQL); 
                $explodeSQL = explode(" ", $this->SQL);

		for($k=0;$k<count($this->contenuResult);$k++){
                    $this->contenuResult[$k] = $this->encode_tabBase($this->contenuResult[$k]);   
		}
            }
            else {
                $this->contenuResult = null; 
            }
	}
        $this->free();
  }

	// Pour ex√©cuter une requ√™te sp√©cifique
  	function requete($SQL){
    	$this->SQL = $SQL;
		$this->exec_SQL();
    	$this->free();
		return $this->contenuResult;
  	}
    
  // Effectue une requÔøΩte SELECT simple
  function requete_select_simple($nomTable, $tri=null, $champ=null, $recherche=null, $sens=null, $limit1=null, $limit2=null, $lang=null){
    // RÔøΩcupÔøΩration de la structure de la table
	$this->getStruct($nomTable);

	$this->SQL = "SELECT * FROM $nomTable";
	
    if($recherche != null){
	  $this->SQL = $this->SQL . " WHERE $champ like '%".addslashes($recherche)."%'";
	}
	
	if($lang != null) {
	  if($recherche != null){
	    $this->SQL = $this->SQL . " AND " . $this->structTab[1] ."=". $lang;
	  }
	  else{
	   $this->SQL = $this->SQL . " WHERE " . $this->structTab[1] ."=". $lang;
      }
	}

	if($tri != null){
	  $this->SQL = $this->SQL . " ORDER BY $tri";
	}
	if($sens != null){
	  $this->SQL = $this->SQL . " $sens";
	}

	if($limit1 != null OR $limit2 != null){
	  $this->SQL = $this->SQL . " LIMIT $limit1, $limit2;";
	}
	$this->exec_SQL();
	return $this->contenuResult;
  }
   //Vérifie si une valeur donnée existe dans une table de la base
   function mysql_exists($nom_table,$nom_attribut,$valeur){
		
		$existe = mysql_query("SELECT `$nom_attribut` FROM `$nom_table` WHERE `$nom_attribut` = '$valeur'") or die("La requête a échouée : $this->SQL".mysql_error());

		if (mysql_num_rows($existe) > 0) {
			return true;
		}
		else {
			return false;
		}
   }
   
   
  //-- RequÔøΩte INSERT
  function requete_insert($nomTable, $tab_valeurs){
	// RÔøΩcupÔøΩration de la structure de la table
	$this->getStruct($nomTable);
    // Encodage des appostrophes ' devient '' et le &quot; deviennent des "
	$tab_valeurs = $this->decode_tabBase($tab_valeurs); 
	// PrÔøΩparation de la requÔøΩte INSERT
	$this->SQL = "INSERT INTO `$nomTable` (";
	$i=0; 
	// PremiÔøΩre partie de la requÔøΩte INSERT
	while($i < $this->nbChamp){
	  if($i == $this->nbChamp - 1){
	    $this->SQL = $this->SQL . " `" . $this->structTab[$i] . "` ) ";  
	  }
	  else {
	    $this->SQL = $this->SQL . " `" . $this->structTab[$i] . "`, "; 
      }
	  $i++;
	}
	$this->SQL = $this->SQL . "VALUES (";
	
	// 2ÔøΩme partie de la requÔøΩte - les donnÔøΩes ÔøΩ insÔøΩrer
	
	// Si le premier champ (la clÔøΩ primaire) est en auto incrÔøΩment
	// on insÔøΩre la valuer ''
	if(@ereg("AUTO_INCREMENT", mysql_field_flags($this->res_result,0))==true){
	  $this->SQL = $this->SQL . "NULL, ";
    }
	else {
		
		if ($tab_valeurs[$this->structTab[0]] != "NULL"){
			$this->SQL = $this->SQL ."'". utf8_decode($tab_valeurs[$this->structTab[0]]) . "', "; 
		}
		else {
			$this->SQL = $this->SQL . "NULL, ";
		}
	}
	$i=1; 
	while($i < $this->nbChamp){
	  if($i == $this->nbChamp - 1){
	    $this->SQL = $this->SQL . "'" . utf8_decode($tab_valeurs[$this->structTab[$i]]) . "' )"; 
	  }
	  else {
	    $this->SQL = $this->SQL . "'" . utf8_decode($tab_valeurs[$this->structTab[$i]]) . "', "; 
	  }
	  $i++;
	}
	//echo $this->SQL; 
	$this->exec_SQL(); 	  
 }
  
  // RequÔøΩte UPDATE
  function requete_update($nomTable, $tab_valeurs, $clee){
    // RÔøΩcupÔøΩration de la structure de la table
	$this->getStruct($nomTable);
    // Encodage des appostrophes ' devient ''
	$tab_valeurs = $this->decode_tabBase($tab_valeurs); 
	// PrÔøΩparation de la requÔøΩte UPDATE
	$this->SQL = "UPDATE $nomTable SET ";
	$i=1;
	while($i < $this->nbChamp){
	  if($i == $this->nbChamp - 1){
	    $this->SQL = $this->SQL . $this->structTab[$i] . " = '" . $tab_valeurs[$this->structTab[$i]] . "' ";
	  }
	  else {
	    $this->SQL = $this->SQL . $this->structTab[$i] . " = '" . $tab_valeurs[$this->structTab[$i]] . "', ";
	  }
	  $i++;
	}
	$this->SQL = $this->SQL . "WHERE ". $this->structTab[0]. " = '" . $clee . "'";
	$this->exec_SQL();
  }
  
  // RequÔøΩte DELETE
  function requete_delete($nomTable, $clee){
    // RÔøΩcupÔøΩration de la structure de la table spÔøΩcifiÔøΩ
    $this->getStruct($nomTable);
    // PrÔøΩparation de la requÔøΩte supression
    $this->SQL = "DELETE FROM $nomTable WHERE ". $this->structTab[0]. "= $clee";
	// ExÔøΩcution de la requÔøΩte
	$this->exec_SQL(); 
  }   

  
  // Code l'enregistrement courrant avec QuoteToHTML
  // Pour ÔøΩviter les problÔøΩmes des " et des formulaires
  function encode_tabBase($tab){ 
	for($i=0;$i<count($this->structTab);$i++){
	  $indice = $this->structTab[$i];
	  if(isset($tab[$indice])){ 
		$tab[$indice] = $this->QuoteToHTML(($tab[$indice])); 
	  }
	}
	return $tab; 	
  }

  // DÔøΩcode l'enregistrement courrant avec HTMLToQuote
  // Lors de l'insertion ou la modification de l'enregistremnt.
  function decode_tabBase($tab){
	for($i=0;$i<count($this->structTab);$i++){
	  $indice = $this->structTab[$i];
	  if(isset($tab[$indice])){
	    $tab[$indice] = $this->HTMLToQuote($tab[$indice]);  
	  }
	}
	return $tab; 	
  }


  // -- Convertie les chaÔøΩnes de caractÔøΩres passÔøΩes en paramÔøΩtres
  // -- de faÔøΩon ÔøΩ ÔøΩviter les problÔøΩmes liÔøΩes aux caractÔøΩres spÔøΩciaux.
  // -- les " deviennent des &quot; 
  function QuoteToHTML($string){
    $string = str_replace('"',"&quot;", $string); 
	
	// Pour mysql 3.23
	$string = utf8_encode(stripslashes($string)); 
	return $string;    
  }
  
  // -- Convertie les chaÔøΩnes de caractÔøΩres passÔøΩes en paramÔøΩtres
  // -- de faÔøΩon ÔøΩ ÔøΩviter les problÔøΩmes liÔøΩes aux caractÔøΩres spÔøΩciaux.
  // -- les &quot; deviennent des " et les ' deviennent des 
  function HTMLToQuote($string) {
   $string = str_replace("&quot;", '"', $string);   
   //$string = str_replace("'","''", $string);
   
   // Pour mysql 3.23
   $string = addslashes($string); 
   return $string; 
  }
  
  function noExecHTML($string){
    $string = str_replace('<',"&lt;", $string); 
    $string = str_replace('>',"&gt;", $string);
	return $string;    
  }
  
}
?>
