﻿<?php
  // Paramètres pour la connexion à la base de données.
  $nomServeur = "localhost";  
  $nomDB = "belotb"; 
  $nomUser = "root";
  $password = "azerty";  
?>
