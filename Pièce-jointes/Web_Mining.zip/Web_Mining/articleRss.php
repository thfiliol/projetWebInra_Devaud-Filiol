<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
	
	
<body>


</body>
</html>
<?php
	
	//Classe représentant des articles aspirés depuis des flux RSS 
	
	class articlesRss 
	{
		private $lien; //Le lien vers l'article aspiré	
		private $description; //La description de l'article dans le flux RSS
		private $titre; //Le titre de l'article dans le flux RSS
		
		
		//Constructeur
		//Paramètres : le titre de l'article, le lien et la description
		
		public function __construct($titre,$lien,$description){
			
			$this->titre=$titre;
			$this->lien=$lien;
			$this->description=$description;
				
		} 
		
		public function getLien () {
		
			return $this->lien;
		}
		
		public function getDescription () {
			
			return $this->description;
		}
		
		public function getTitre () {
			
			return $this->titre;
		}
	
	}

?>
